
    <nav id="myNavmenu" class="navmenu navmenu-default navmenu-fixed-left offcanvas-sm" role="navigation">
        <div class="list-group panel">
            <p class=" list-group-item siderbar-top" title=""><img src="<?php echo e(url('images/flarepoint_logo.png')); ?>" alt=""></p>
            <a href="<?php echo e(route('dashboard', \Auth::id())); ?>" class=" list-group-item" data-parent="#MainMenu"><i
                        class="glyphicon sidebar-icon glyphicon-dashboard"></i><span id="menu-txt"><?php echo e(__('Dashboard')); ?></span> </a>
            <a href="<?php echo e(route('users.show', \Auth::id())); ?>" class=" list-group-item" data-parent="#MainMenu"><i
                        class="glyphicon sidebar-icon glyphicon-user"></i><span id="menu-txt"><?php echo e(__('Profile')); ?></span> </a>


            <a href="#clients" class=" list-group-item" data-toggle="collapse" data-parent="#MainMenu"><i
                        class="glyphicon sidebar-icon glyphicon-tag"></i><span id="menu-txt"><?php echo e(__('Clients')); ?></span>
            <i class="ion-chevron-up  arrow-up sidebar-arrow"></i></a>
            <div class="collapse" id="clients">

                <a href="<?php echo e(route('clients.index')); ?>" class="list-group-item childlist"><?php echo e(__('All Clients')); ?></a>
                <?php if(Entrust::can('client-create')): ?>
                    <a href="<?php echo e(route('clients.create')); ?>"
                       class="list-group-item childlist"><?php echo e(__('New Client')); ?></a>
                <?php endif; ?>
            </div>

            <a href="#tasks" class="list-group-item" data-toggle="collapse" data-parent="#MainMenu"><i
                        class="glyphicon sidebar-icon glyphicon-tasks"></i><span id="menu-txt"><?php echo e(__('Tasks')); ?></span>
            <i class="ion-chevron-up  arrow-up sidebar-arrow"></i></a>
            <div class="collapse" id="tasks">
                <a href="<?php echo e(route('tasks.index')); ?>" class="list-group-item childlist"><?php echo e(__('All Tasks')); ?></a>
                <?php if(Entrust::can('task-create')): ?>
                    <a href="<?php echo e(route('tasks.create')); ?>" class="list-group-item childlist"><?php echo e(__('New Task')); ?></a>
                <?php endif; ?>
            </div>

            <a href="#user" class=" list-group-item" data-toggle="collapse" data-parent="#MainMenu"><i
                        class="sidebar-icon fa fa-users"></i><span id="menu-txt"><?php echo e(__('Users')); ?></span>
            <i class="ion-chevron-up  arrow-up sidebar-arrow"></i></a>
            <div class="collapse" id="user">
                <a href="<?php echo e(route('users.index')); ?>" class="list-group-item childlist"><?php echo e(__('Users All')); ?></a>
                <?php if(Entrust::can('user-create')): ?>
                    <a href="<?php echo e(route('users.create')); ?>"
                       class="list-group-item childlist"><?php echo e(__('New User')); ?></a>
                <?php endif; ?>
            </div>

            <a href="#leads" class=" list-group-item" data-toggle="collapse" data-parent="#MainMenu"><i
                        class="glyphicon sidebar-icon glyphicon-hourglass"></i><span id="menu-txt"><?php echo e(__('Leads')); ?></span>
            <i class="ion-chevron-up  arrow-up sidebar-arrow"></i></a>
            <div class="collapse" id="leads">
                <a href="<?php echo e(route('leads.index')); ?>" class="list-group-item childlist"><?php echo e(__('All Leads')); ?></a>
                <?php if(Entrust::can('lead-create')): ?>
                    <a href="<?php echo e(route('leads.create')); ?>"
                       class="list-group-item childlist"><?php echo e(__('New Lead')); ?></a>
                <?php endif; ?>
            </div>
            <a href="#departments" class=" list-group-item" data-toggle="collapse" data-parent="#MainMenu"><i
                        class="sidebar-icon glyphicon glyphicon-list-alt"></i><span id="menu-txt"><?php echo e(__('Departments')); ?></span>
            <i class="ion-chevron-up  arrow-up sidebar-arrow"></i></a>
            <div class="collapse" id="departments">
                <a href="<?php echo e(route('departments.index')); ?>"
                   class="list-group-item childlist"><?php echo e(__('All Departments')); ?></a>
                <?php if(Entrust::hasRole('administrator')): ?>
                    <a href="<?php echo e(route('departments.create')); ?>"
                       class="list-group-item childlist"><?php echo e(__('New Department')); ?></a>
                <?php endif; ?>
            </div>

            <?php if(Entrust::hasRole('administrator')): ?>
                <a href="#settings" class=" list-group-item" data-toggle="collapse" data-parent="#MainMenu"><i
                            class="glyphicon sidebar-icon glyphicon-cog"></i><span id="menu-txt"><?php echo e(__('Settings')); ?></span>
                <i class="ion-chevron-up  arrow-up sidebar-arrow"></i></a>
                <div class="collapse" id="settings">
                    <a href="<?php echo e(route('settings.index')); ?>"
                       class="list-group-item childlist"><?php echo e(__('Overall Settings')); ?></a>

                    <a href="<?php echo e(route('roles.index')); ?>"
                       class="list-group-item childlist"><?php echo e(__('Role Management')); ?></a>
                    <a href="<?php echo e(route('integrations.index')); ?>"
                       class="list-group-item childlist"><?php echo e(__('Integrations')); ?></a>
                </div>


            <?php endif; ?>
            <a href="<?php echo e(url('/logout')); ?>" class=" list-group-item impmenu" data-parent="#MainMenu"><i
                        class="glyphicon sidebar-icon glyphicon-log-out"></i><span id="menu-txt"><?php echo e(__('Sign Out')); ?></span> </a>

        </div>
    </nav>
