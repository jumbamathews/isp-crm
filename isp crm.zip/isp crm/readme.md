## Installation 
- Create an empty database table
- -Copy the .env.example to .env and insert the Database config
- Run the following commands
    - composer install
    - php artisan migrate --seed
    - php artisan key:generate
- login in with these credentials Mail: admin@admin.com Password: admin123 (Can be changed in the dashboard)


## Features overview
- Tasks management
- Leads management
- Simple invoice management
- Easy & simple time management for each task
- Role management (Create and update your own roles)
- Easy configurable settings
- Client overview (Keep easy track of open tasks for each client etc)
- Upload documents to each clients (easy track of contracts and more)
- Fast overview over your own open tasks, leads etc
- Global dashboard
The system assumes that all clients are registered and communication is done through emails. Messages can be integrated at a later stage if needed.

### To-do

The CRM  is open for further development, so there are a lot on my to-do list.

- Multiple integrations (Slack, e-conomic, Google Drive, dropbox etc.)
- Different Color schemes
- API
- Excel Import/export
- Better cache
- Even easier installation

And much more (in no particular order)


### Packages
The packages used are the following...

- [LaravelCollective](https://github.com/LaravelCollective/html)
- [laravel-datatables](https://github.com/yajra/laravel-datatables)
- [Entrust](https://github.com/Zizaco/entrust)


### License

